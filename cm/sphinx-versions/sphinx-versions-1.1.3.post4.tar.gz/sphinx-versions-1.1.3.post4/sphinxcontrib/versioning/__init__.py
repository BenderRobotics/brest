"""
Sphinx extension that allows building versioned docs for self-hosting.
"""

__author__ = 'Venglar'
__license__ = 'MIT'
__version__ = '1.1.3.post2.BR'
